#ifndef BST_FILA_H
#define BST_FILA_H


#include "fila.h"


typedef struct bst {
    int prioridade;
    Fila* fila;
    struct bst* esq; // ponteiro para esq
    struct bst* dir; // ponteiro para dir
} BST;


BST* bst_criar();
BST* bst_inserir(BST* raiz, Ficha ficha);
Ficha* bst_remover_ficha(BST** raiz);
int bst_vazia(BST* raiz);
void bst_destruir(BST* raiz);
void bst_salvar_arquivo(BST* raiz, const char* nome);
BST* bst_carregar_arquivo(const char* nome);
Ficha* bst_proxima_ficha(BST* raiz); 


#endif


