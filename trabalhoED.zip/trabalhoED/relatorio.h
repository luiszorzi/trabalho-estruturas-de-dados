#ifndef RELATORIO_H
#define RELATORIO_H

#include <stddef.h> // Para size_t

typedef struct {
    char nome[100];
    int quantidade;
} Especialidade;

typedef struct {
    Especialidade* especialidades;
    size_t tamanho;     // numero atual de especialidades
    size_t capacidade;  // quantos elementos cabem 
} RelatorioEspecialidades;


RelatorioEspecialidades* relatorio_criar();
void relatorio_adicionar_especialidade(RelatorioEspecialidades* relatorio, const char* nome_especialidade);
void relatorio_imprimir(RelatorioEspecialidades* relatorio);
void relatorio_destruir(RelatorioEspecialidades* relatorio);
void relatorio_salvar_arquivo(RelatorioEspecialidades* relatorio, const char* nome_arquivo);
RelatorioEspecialidades* relatorio_carregar_arquivo(const char* nome_arquivo);

#endif