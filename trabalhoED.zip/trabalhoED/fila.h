#ifndef FILA_H
#define FILA_H


typedef struct {
    int id;
    int prioridade;
    char nome[100];
    char especialidade[100];
    int tempo;
} Ficha;


typedef struct no {
    Ficha ficha; // dados da ficha armazenados no nó
    struct no* prox; // ponteiro para o proximo no da fila
} No;


typedef struct {
    No* inicio; 
    No* fim;
} Fila;


Fila* fila_criar();                                     // Cria uma novo fila vazia
void fila_inserir(Fila* f, Ficha ficha);                // Insere uma nova ficha no final da fila
Ficha* fila_remover(Fila* f);                           // Remove e retorna a ficha do inicio da fila
int fila_vazia(Fila* f);                                // Verifica se a fila esta vazia
void fila_destruir(Fila* f);                            // Libera a memoria
void fila_salvar_arquivo(Fila* f, const char* nome);    // Salva todas as fichas da fila
Fila* fila_carregar_arquivo(const char* nome);          // Le as fichas e monta a fila


#endif