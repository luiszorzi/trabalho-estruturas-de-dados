#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "fila.h"
#include "bst_fila.h"
#include "tad_configs.h"

void processar_inbox(BST** bst, Fila* fila) {
    FILE* inbox_file = fopen("inbox.dat", "rb");
    if (inbox_file == NULL) {
        return; 
    }

    Ficha f;
    while (fread(&f, sizeof(Ficha), 1, inbox_file) == 1) {
        if (f.prioridade == 6) {
            fila_inserir(fila, f);
        } else {
            *bst = bst_inserir(*bst, f);
        }
    }

    fclose(inbox_file);
    remove("inbox.dat"); // para nao ler 2 vezes
}

int main() {
    printf("Simulacao de atendimento iniciada.\n\n");

    TadConfigs* configs = configs_inicializar();

    while (1) {
        configs_ler(configs);

        if (configs->configs.status == TERMINAR) {
            printf("\nComando TERMINAR recebido. Encerrando e limpando dados.\n");
            
            // Apaga todos os arquivos de dados da sessão
            remove("fila.dat");
            remove("bst.dat");
            remove("relatorio.dat");
            remove("inbox.dat");
            remove("config.dat");
            
            break; 
        }
      
        
        Fila* fila = fila_carregar_arquivo("fila.dat");
        BST* bst = bst_carregar_arquivo("bst.dat");
        
        processar_inbox(&bst, fila);

        if (configs->configs.status == AGUARDAR) {
            printf("\nSimulacao em modo AGUARDAR.\n");
            
            printf("------------------------------------------------\n");
            Ficha* proxima_prioridade = bst_proxima_ficha(bst);
            Ficha* proxima_comum = (fila && fila->inicio) ? &(fila->inicio->ficha) : NULL;
            
            printf("Proximo com prioridade: %s\n", proxima_prioridade ? proxima_prioridade->nome : "Fila vazia.");
            printf("Proximo sem prioridade: %s\n", proxima_comum ? proxima_comum->nome : "Fila vazia.");
            printf("------------------------------------------------\n");
            
            Sleep(5000);
        } 
        else if (configs->configs.status == SIMULAR) {
            Ficha* atendido = NULL;
            if (!bst_vazia(bst)) {
                atendido = bst_remover_ficha(&bst);
            } else if (!fila_vazia(fila)) {
                atendido = fila_remover(fila);
            }

            if (atendido) {
                printf("\nProcessando: %s (ID %d, Prioridade %d, Especialidade %s, Tempo %d seg)\n",
                       atendido->nome, atendido->id, atendido->prioridade, atendido->especialidade, atendido->tempo);

                Ficha* proxima_prioridade = bst_proxima_ficha(bst);
                Ficha* proxima_comum = (fila && fila->inicio) ? &(fila->inicio->ficha) : NULL;
                    
                printf("Proximo com prioridade: %s\n", proxima_prioridade ? proxima_prioridade->nome : "Fila vazia.");
                printf("Proximo sem prioridade: %s\n", proxima_comum ? proxima_comum->nome : "Fila vazia.");
                printf("------------------------------------------------\n");
                
                Sleep(atendido->tempo * 1000);
                free(atendido);
            } else {
                printf("\nFila vazia. Esperando por novas fichas.\n");
                Sleep(5000);
            }
        }

        fila_salvar_arquivo(fila, "fila.dat");
        bst_salvar_arquivo(bst, "bst.dat");

        fila_destruir(fila);
        bst_destruir(bst);
    }

    configs_destruir(configs);
    return 0;
}