#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "fila.h"
#include "bst_fila.h"
#include "tad_configs.h"
#include "relatorio.h"


int main() {
    srand(time(NULL));


    TadConfigs* configs = configs_inicializar(); // inicializa a estrutura de configurações
   
    int opcao;
    static int id_atual = 1;
   
    while (1) {
        printf("\nMenu:\n");
        printf("1 - Criar ficha\n");
        printf("2 - Aguardar\n");
        printf("3 - Simular atendimento\n");
        printf("4 - Mostrar relatorio de especialidades\n");
        printf("5 - Terminar Simulacao\n");
        printf("0 - Sair do Menu\n");
        printf("Escolha: ");
        scanf("%d", &opcao);


        if (opcao == 0) {
            // Fecha o menu
            break;
        }


        switch (opcao) {
            case 1: {
                RelatorioEspecialidades* relatorio = relatorio_carregar_arquivo("relatorio.dat");
                Ficha f;
                f.id = id_atual++;
                f.tempo = rand() % 10 + 1;


                printf("Nome: ");
                getchar();
                fgets(f.nome, 100, stdin);
                f.nome[strcspn(f.nome, "\n")] = '\0';


                printf("Prioridade (1-6): ");
                scanf("%d", &f.prioridade);
                if (f.prioridade < 1 || f.prioridade > 6) {
                    printf("Prioridade invalida. Usando 6 (fila comum).\n");
                    f.prioridade = 6;
                }


                printf("Especialidade: ");
                getchar();
                fgets(f.especialidade, 100, stdin);
                f.especialidade[strcspn(f.especialidade, "\n")] = '\0';


                FILE* inbox_file = fopen("inbox.dat", "ab"); // Abre o arquivo em modo append binary (adicionar no fim, em binário).
                if (!inbox_file) {
                    printf("Nao foi possivel abrir a caixa de entrada (inbox.dat)\n");
                } else {
                    fwrite(&f, sizeof(Ficha), 1, inbox_file);
                    fclose(inbox_file);
                    printf("Ficha enviada para a simulacao com sucesso.\n");
                }


                relatorio_adicionar_especialidade(relatorio, f.especialidade);
                printf("Ficha criada: ID %d, Nome %s, Prioridade %d, Especialidade %s, Tempo %d seg\n",
                       f.id, f.nome, f.prioridade, f.especialidade, f.tempo);
               
                relatorio_salvar_arquivo(relatorio, "relatorio.dat");
                relatorio_destruir(relatorio);
                break;
            }
            case 2: {
                configs->configs.status = AGUARDAR;
                configs_salvar(configs);
                printf("Status de simulacao definido para AGUARDAR.\n");
                break;
            }
            case 3: {
                configs->configs.status = SIMULAR;
                configs_salvar(configs);
                printf("Status de simulacao definido para SIMULAR ATENDIMENTO.\n");
                break;
            }
            case 4: {
                RelatorioEspecialidades* relatorio = relatorio_carregar_arquivo("relatorio.dat");
                relatorio_imprimir(relatorio);
                relatorio_destruir(relatorio);
                break;
            }
            case 5: {
                configs->configs.status = TERMINAR;
                configs_salvar(configs);
                printf("Comando TERMINAR enviado. A simulacao sera encerrada e os dados apagados.\n");
                break;
            }
            default: {
                printf("Opcao invalida. Escolha uma opcao valida.\n");
            }
        }
    }


    configs_destruir(configs);
    printf("Programa menu encerrado.\n");
    return 0;
}