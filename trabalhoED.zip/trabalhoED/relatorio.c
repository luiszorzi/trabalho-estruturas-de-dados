#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "relatorio.h"


#define CAPACIDADE_INICIAL 5 // Capacidade inicial do array de especialidades


RelatorioEspecialidades* relatorio_criar() {
    RelatorioEspecialidades* relatorio = (RelatorioEspecialidades*) malloc(sizeof(RelatorioEspecialidades));
    if (relatorio == NULL) {
        printf("Erro ao alocar memoria para o relatorio\n");
        exit(EXIT_FAILURE);
    }
    relatorio->tamanho = 0;
    relatorio->capacidade = CAPACIDADE_INICIAL;
    relatorio->especialidades = (Especialidade*) malloc(relatorio->capacidade * sizeof(Especialidade));
    if (relatorio->especialidades == NULL) {
        printf("Erro ao alocar memoria para o array de especialidades\n");
        free(relatorio);
        exit(EXIT_FAILURE);
    }
    return relatorio;
}


void relatorio_adicionar_especialidade(RelatorioEspecialidades* relatorio, const char* nome_especialidade) {
    // Procura se a especialidade já existe
    for (size_t i = 0; i < relatorio->tamanho; i++) {
        if (strcmp(relatorio->especialidades[i].nome, nome_especialidade) == 0) {
            relatorio->especialidades[i].quantidade++;
            return;
        }
    }


    // Se a especialidade não existe, adiciona uma nova
    if (relatorio->tamanho == relatorio->capacidade) {
        // Redimensiona o array se a capacidade for atingida
        relatorio->capacidade *= 2;
        relatorio->especialidades = (Especialidade*) realloc(relatorio->especialidades, relatorio->capacidade * sizeof(Especialidade));
        if (relatorio->especialidades == NULL) {
            printf("Erro ao realocar memoria para o array de especialidades\n");
            exit(EXIT_FAILURE);
        }
    }


    // Adiciona a nova especialidade
    strncpy(relatorio->especialidades[relatorio->tamanho].nome, nome_especialidade, sizeof(relatorio->especialidades[relatorio->tamanho].nome) - 1); // copia a especialidade 
    relatorio->especialidades[relatorio->tamanho].nome[sizeof(relatorio->especialidades[relatorio->tamanho].nome) - 1] = '\0'; // Garante terminação nula
    relatorio->especialidades[relatorio->tamanho].quantidade = 1; // adiciona a primeira especialidade
    relatorio->tamanho++;
}


void relatorio_imprimir(RelatorioEspecialidades* relatorio) {
    printf("\n--- Relatorio de Especialidades Requisitadas ---\n");
    if (relatorio->tamanho == 0) {
        printf("Nenhuma especialidade registrada ainda.\n");
        return;
    }
    for (size_t i = 0; i < relatorio->tamanho; i++) {
        printf("%s: %d\n", relatorio->especialidades[i].nome, relatorio->especialidades[i].quantidade);
    }
    printf("-------------------------------------------------\n");
}


void relatorio_destruir(RelatorioEspecialidades* relatorio) {
    if (relatorio) {
        free(relatorio->especialidades);
        free(relatorio);
    }
}


void relatorio_salvar_arquivo(RelatorioEspecialidades* relatorio, const char* nome_arquivo) {
    FILE* arq = fopen(nome_arquivo, "wb");
    if (!arq) {
        printf("Erro ao abrir arquivo para salvar relatorio\n");
        return;
    }
    // Salva o tamanho do array primeiro(total especialidades)
    fwrite(&relatorio->tamanho, sizeof(size_t), 1, arq);
    // Salva cada especialidade(dados)
    for (size_t i = 0; i < relatorio->tamanho; i++) {
        fwrite(&relatorio->especialidades[i], sizeof(Especialidade), 1, arq);
    }
    fclose(arq);
}


RelatorioEspecialidades* relatorio_carregar_arquivo(const char* nome_arquivo) {
    RelatorioEspecialidades* relatorio = relatorio_criar(); // Cria um relatório vazio
    FILE* arq = fopen(nome_arquivo, "rb");
    if (!arq) {
        return relatorio; 
    }


    size_t tamanho_salvo; 
    fread(&tamanho_salvo, sizeof(size_t), 1, arq); // le do arquivo o tamanho(quantas especialidades tem)


    // Redimensiona o array para a capacidade necessária antes de carregar
    if (tamanho_salvo > relatorio->capacidade) {
        relatorio->capacidade = tamanho_salvo * 2; // Garante espaço suficiente
        relatorio->especialidades = (Especialidade*) realloc(relatorio->especialidades, relatorio->capacidade * sizeof(Especialidade));
        if (relatorio->especialidades == NULL) {
            printf("Erro ao realocar memoria para carregar relatorio\n");
            free(relatorio);
            fclose(arq);
            exit(EXIT_FAILURE);
        }
    }
   
    // Carrega as especialidades
    fread(relatorio->especialidades, sizeof(Especialidade), tamanho_salvo, arq);
    relatorio->tamanho = tamanho_salvo; // Atualiza o tamanho real


    fclose(arq);
    return relatorio;
}




