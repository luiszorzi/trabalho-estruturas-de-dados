#ifndef TAD_CONFIGS_H
#define TAD_CONFIGS_H


typedef enum {
    AGUARDAR,   
    SIMULAR,    
    TERMINAR,   
} Status;


typedef struct {
    Status status;
} Configs;


typedef struct {
    Configs configs;
} TadConfigs;


TadConfigs* configs_inicializar();
void configs_ler(TadConfigs* configs);
void configs_salvar(TadConfigs* configs);
void configs_destruir(TadConfigs* configs);


#endif