#include <stdio.h>
#include <stdlib.h>
#include "tad_configs.h"


TadConfigs* configs_inicializar() {
    TadConfigs* configs = (TadConfigs*) malloc(sizeof(TadConfigs));
    if (configs) {
        configs->configs.status = AGUARDAR; // Inicia em AGUARDAR
    } else {
        printf("Erro: falha ao alocar memoria para TadConfigs\n");
        exit(EXIT_FAILURE);
    }
    return configs;
}


void configs_ler(TadConfigs* configs) {
    FILE* f = fopen("config.dat", "rb");
    if (!f) {
        
        configs->configs.status = AGUARDAR; 
        return;
    }

    fread(&configs->configs, sizeof(Configs), 1, f);
    fclose(f);
}


void configs_salvar(TadConfigs* configs) {
    FILE* f = fopen("config.dat", "wb"); 
    if (!f) {
        printf("Erro: nao foi possivel abrir o arquivo para salvar configuracoes\n");
        return;
    }


    fwrite(&configs->configs, sizeof(Configs), 1, f);
    fclose(f);
}


void configs_destruir(TadConfigs* configs) {
    if (configs) {
        free(configs);
    }
}