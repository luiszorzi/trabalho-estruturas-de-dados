#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fila.h"
#ifdef _WIN32
#include <io.h>
#endif


Fila* fila_criar() {
    Fila* f = (Fila*) malloc(sizeof(Fila));
    if (f == NULL) {
        printf("Erro: falha ao alocar memoria para a fila\n");
        exit(EXIT_FAILURE);
    }
    f->inicio = f->fim = NULL;
    return f;
}


void fila_inserir(Fila* f, Ficha ficha) {
    No* novo = (No*) malloc(sizeof(No));
    if (novo == NULL) {
        printf("Erro: falha ao alocar memoria para o no da fila\n");
        exit(EXIT_FAILURE);
    }
    novo->ficha = ficha; // é copiado o conteudo ficha para o novo no
    novo->prox = NULL;
    if (f->fim) f->fim->prox = novo; // Se a fila não está vazia, liga o último nó atual ao novo
    else f->inicio = novo; // se esta vazia, define o novo no como primeiro
    f->fim = novo; // atualiza o ponteiro fim para o novo no
}


Ficha* fila_remover(Fila* f) {
    if (!f->inicio) return NULL; // Se a fila estiver vazia, retorna NULL
    No* temp = f->inicio;
    Ficha* ficha = (Ficha*) malloc(sizeof(Ficha));
    if (ficha == NULL) {
        printf("Erro: falha ao alocar memoria para a ficha removida\n");
        exit(EXIT_FAILURE);
    }
    *ficha = temp->ficha; // copia os dados da ficha do nó a ser removido
    f->inicio = temp->prox; // atualiza inicio para proximo no
    if (!f->inicio) f->fim = NULL; // Se a fila ficou vazia, atualiza o fim para NULL
    free(temp);
    return ficha;
}


int fila_vazia(Fila* f) {
    return f->inicio == NULL;
}


void fila_destruir(Fila* f) {
    while (!fila_vazia(f)) {
        Ficha* temp = fila_remover(f);
        free(temp);
    }
    free(f);
}


void fila_salvar_arquivo(Fila* f, const char* nome) {
    FILE* arq = fopen(nome, "wb"); // wb para sobreescrever
    if (!arq) {
        printf("Erro: nao foi possivel abrir o arquivo %s para salvar\n", nome);
        return;
    }
    No* atual = f->inicio;
    while (atual) {
        fwrite(&atual->ficha, sizeof(Ficha), 1, arq);
        atual = atual->prox;
    }
    fflush(arq);  // garantir que todos buffers sejam gravados no arquivo
#ifdef _WIN32
    _commit(_fileno(arq)); // Força a escrita para o disco no windows
#endif
    fclose(arq);
}


Fila* fila_carregar_arquivo(const char* nome) {
    FILE* arq = fopen(nome, "rb");
    Fila* f = fila_criar();
    if (!arq) {
        printf("Aviso: nao foi possivel abrir o arquivo %s para carregar (arquivo pode nao existir)\n", nome);
        return f;
    }
    Ficha ficha;
    while (fread(&ficha, sizeof(Ficha), 1, arq) == 1) {
        fila_inserir(f, ficha);
    }
    fclose(arq);
    return f;
}
