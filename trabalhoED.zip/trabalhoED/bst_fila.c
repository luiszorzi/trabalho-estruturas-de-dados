#include <stdio.h>
#include <stdlib.h>
#include "bst_fila.h"
#ifdef _WIN32
#include <io.h> // Para _commit no Windows
#endif


BST* bst_criar() {
    return NULL;
}


BST* bst_inserir(BST* raiz, Ficha ficha) {
    if (!raiz) {
        BST* novo = (BST*) malloc(sizeof(BST)); // novo no é alocado
        if (novo == NULL) {
            printf("Erro: falha ao alocar memoria para o no da BST\n");
            exit(EXIT_FAILURE);
        }
        novo->prioridade = ficha.prioridade; // Define a prioridade do novo no de acordo com a ficha que está sendo inserida
        novo->fila = fila_criar(); // nova fila criada dentro do no
        fila_inserir(novo->fila, ficha);
        novo->esq = novo->dir = NULL;
        return novo;
    }


    if (ficha.prioridade < raiz->prioridade) {
        raiz->esq = bst_inserir(raiz->esq, ficha);
    } else if (ficha.prioridade > raiz->prioridade) {
        raiz->dir = bst_inserir(raiz->dir, ficha);
    } else {
        fila_inserir(raiz->fila, ficha);
    }


    return raiz;
}


int bst_vazia(BST* raiz) {
    return raiz == NULL;
}


Ficha* bst_remover_ficha(BST** raiz) {
    if (!(*raiz)) return NULL;


    if ((*raiz)->esq) {
        return bst_remover_ficha(&(*raiz)->esq); // chama o filho mais da esq
    } else {
        Ficha* ficha = fila_remover((*raiz)->fila); // remove a primeira ficha associada ao no
        if (fila_vazia((*raiz)->fila)) {
            fila_destruir((*raiz)->fila);
            BST* temp = *raiz;
            *raiz = (*raiz)->dir; // substitui o no atual pelo o da direita se existir
            free(temp);
        }
        return ficha;
    }
}


void bst_destruir(BST* raiz) {
    if (!raiz) return;
    bst_destruir(raiz->esq);
    bst_destruir(raiz->dir);
    fila_destruir(raiz->fila);
    free(raiz);
}


static void bst_salvar_arquivo_recursivo(BST* raiz, FILE* arq) {
    if (!raiz) return;


    bst_salvar_arquivo_recursivo(raiz->esq, arq); // salva primeiro as prioridades menores(esq)


    No* atual = raiz->fila->inicio;
    while (atual) {
        fwrite(&atual->ficha, sizeof(Ficha), 1, arq);
        atual = atual->prox;
    }


    bst_salvar_arquivo_recursivo(raiz->dir, arq);
}


void bst_salvar_arquivo(BST* raiz, const char* nome) {
    FILE* arq = fopen(nome, "wb");
    if (!arq) {
        printf("Erro: nao foi possivel abrir o arquivo %s para salvar BST\n", nome);
        return;
    }


    bst_salvar_arquivo_recursivo(raiz, arq);


    fflush(arq); // força a gravação imediata dos dados do buffer no arquivo
#ifdef _WIN32
    _commit(_fileno(arq));
#endif
    fclose(arq);
}


BST* bst_carregar_arquivo(const char* nome) {
    FILE* arq = fopen(nome, "rb");
    if (!arq) {
        return NULL;
    }
    BST* bst = NULL; // inicializa a arvore vazia
    Ficha ficha;
    while (fread(&ficha, sizeof(Ficha), 1, arq) == 1) {
        bst = bst_inserir(bst, ficha); // insere a ficha lida na bst
    }
    fclose(arq);
    return bst;
}


Ficha* bst_proxima_ficha(BST* raiz) {
    if (!raiz) return NULL;
    // percorre a arvore para a esquerda ate encontrar o no com a menor prioridade
    while (raiz->esq) {
        raiz = raiz->esq;
    }
    // Retorna a primeira ficha da fila associada a essa prioridade
    if (raiz->fila && raiz->fila->inicio) {
        return &(raiz->fila->inicio->ficha); // Retorna um ponteiro para a ficha
    }
    return NULL;
}
